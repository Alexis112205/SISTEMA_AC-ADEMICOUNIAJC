package com.uniajc.servicios;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.uniajc.dao.GrupoDao;
import com.uniajc.dao.MateriaDao;
import com.uniajc.modelo.Materia;

/**
 * Pruebas del servicio SIN base de datos: se usa un DAO falso en memoria.
 */
class MateriaServiceTest {

    /** DAO falso que guarda en una lista en vez de ir a PostgreSQL. */
    private static class MateriaDaoFalso extends MateriaDao {
        private final List<Materia> datos = new ArrayList<>();
        private int siguienteId = 1;

        @Override
        public void guardar(Materia m) {
            m.setId(siguienteId++);
            datos.add(m);
        }

        @Override
        public List<Materia> obtenerTodos() {
            return new ArrayList<>(datos);
        }

        @Override
        public Optional<Materia> buscarPorId(int id) {
            return datos.stream().filter(m -> m.getId() == id).findFirst();
        }

        @Override
        public void actualizar(Materia nueva) {
            for (int i = 0; i < datos.size(); i++) {
                if (datos.get(i).getId() == nueva.getId()) {
                    datos.set(i, nueva);
                }
            }
        }

        @Override
        public void eliminar(int id) {
            datos.removeIf(m -> m.getId() == id);
        }
    }

    /** GrupoDao falso: simula cuantos grupos tiene una materia, sin base de datos. */
    private static class GrupoDaoFalso extends GrupoDao {
        private final int grupos;

        GrupoDaoFalso(int grupos) {
            this.grupos = grupos;
        }

        @Override
        public int contarPorMateria(int idMateria) {
            return grupos;
        }
    }

    private MateriaService servicio;

    @BeforeEach
    void preparar() {
        servicio = new MateriaService(new MateriaDaoFalso());
    }

    @Test
    void registraMateriaValida() {
        servicio.registrarMateria(new Materia("Bases de Datos II", 3));
        assertEquals(1, servicio.obtenerTodasLasMaterias().size());
    }

    @Test
    void aceptaLosLimitesDeCreditos() {
        servicio.registrarMateria(new Materia("Seminario", 1));
        servicio.registrarMateria(new Materia("Proyecto Integrador", 10));
        assertEquals(2, servicio.obtenerTodasLasMaterias().size());
    }

    @Test
    void rechazaNombreVacio() {
        assertThrows(IllegalArgumentException.class, () -> servicio.registrarMateria(new Materia("  ", 3)));
    }

    @Test
    void rechazaNombreMuyCorto() {
        assertThrows(IllegalArgumentException.class, () -> servicio.registrarMateria(new Materia("ab", 3)));
    }

    @Test
    void rechazaCreditosCero() {
        assertThrows(IllegalArgumentException.class, () -> servicio.registrarMateria(new Materia("Algebra", 0)));
    }

    @Test
    void rechazaCreditosMayoresA10() {
        assertThrows(IllegalArgumentException.class, () -> servicio.registrarMateria(new Materia("Algebra", 11)));
    }

    @Test
    void actualizaMateriaExistente() {
        servicio.registrarMateria(new Materia("Algebra", 3));
        servicio.actualizarMateria(new Materia(1, "Algebra Lineal", 4));
        assertEquals(4, servicio.buscarMateriaPorId(1).get().getCredits());
    }

    @Test
    void noActualizaMateriaInexistente() {
        assertThrows(IllegalArgumentException.class,
                () -> servicio.actualizarMateria(new Materia(99, "Fisica", 3)));
    }

    @Test
    void eliminaMateriaExistente() {
        servicio.registrarMateria(new Materia("Algebra", 3));
        servicio.eliminarMateria(1);
        assertTrue(servicio.obtenerTodasLasMaterias().isEmpty());
    }

    @Test
    void rechazaEliminarConIdInvalido() {
        assertThrows(IllegalArgumentException.class, () -> servicio.eliminarMateria(0));
    }

    @Test
    void rechazaEliminarMateriaInexistente() {
        assertThrows(IllegalArgumentException.class, () -> servicio.eliminarMateria(5));
    }

    @Test
    void rechazaEliminarMateriaConGrupos() {
        MateriaService conGrupos = new MateriaService(new MateriaDaoFalso(), new GrupoDaoFalso(2));
        conGrupos.registrarMateria(new Materia("Algebra", 3));
        assertThrows(IllegalArgumentException.class, () -> conGrupos.eliminarMateria(1));
        assertEquals(1, conGrupos.obtenerTodasLasMaterias().size());
    }

    @Test
    void eliminaMateriaSinGrupos() {
        MateriaService sinGrupos = new MateriaService(new MateriaDaoFalso(), new GrupoDaoFalso(0));
        sinGrupos.registrarMateria(new Materia("Algebra", 3));
        sinGrupos.eliminarMateria(1);
        assertTrue(sinGrupos.obtenerTodasLasMaterias().isEmpty());
    }
}

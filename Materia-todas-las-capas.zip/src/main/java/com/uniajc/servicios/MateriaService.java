package com.uniajc.servicios;

import java.util.List;
import java.util.Optional;

import com.uniajc.dao.GrupoDao;
import com.uniajc.dao.MateriaDao;
import com.uniajc.modelo.Materia;

/**
 * Capa de Servicios para Materia: logica de negocio y validaciones antes de llamar al DAO.
 * Regla de la base de datos: los creditos deben estar entre 1 y 10.
 */
public class MateriaService {

    public static final int CREDITOS_MIN = 1;
    public static final int CREDITOS_MAX = 10;

    private final MateriaDao materiaDao;
    private final GrupoDao grupoDao;

    /** Constructor sin proteccion de borrado (no consulta grupos). */
    public MateriaService(MateriaDao materiaDao) {
        this(materiaDao, null);
    }

    /** Constructor completo: con GrupoDao se impide borrar materias que tienen grupos. */
    public MateriaService(MateriaDao materiaDao, GrupoDao grupoDao) {
        if (materiaDao == null) {
            throw new IllegalArgumentException("El DAO no puede ser nulo.");
        }
        this.materiaDao = materiaDao;
        this.grupoDao = grupoDao;
    }

    public void registrarMateria(Materia materia) {
        validarMateria(materia);
        materiaDao.guardar(materia);
    }

    public List<Materia> obtenerTodasLasMaterias() {
        return materiaDao.obtenerTodos();
    }

    public Optional<Materia> buscarMateriaPorId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("El ID debe ser mayor a cero.");
        }
        return materiaDao.buscarPorId(id);
    }

    public Optional<Materia> buscarPorId(int id) {
        return buscarMateriaPorId(id);
    }

    public void actualizarMateria(Materia materia) {
        if (materia == null || materia.getId() <= 0) {
            throw new IllegalArgumentException("Materia invalida para actualizar.");
        }
        if (materiaDao.buscarPorId(materia.getId()).isEmpty()) {
            throw new IllegalArgumentException("No se encontro ninguna materia con ID: " + materia.getId());
        }
        validarMateria(materia);
        materiaDao.actualizar(materia);
    }

    public void eliminarMateria(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("El ID debe ser mayor a cero.");
        }
        if (materiaDao.buscarPorId(id).isEmpty()) {
            throw new IllegalArgumentException("No se encontro ninguna materia con ID: " + id);
        }
        if (grupoDao != null) {
            int grupos = grupoDao.contarPorMateria(id);
            if (grupos > 0) {
                throw new IllegalArgumentException(
                        "No se puede eliminar la materia: tiene " + grupos + " grupo(s) asociado(s).");
            }
        }
        materiaDao.eliminar(id);
    }

    private void validarMateria(Materia m) {
        if (m == null) {
            throw new IllegalArgumentException("El objeto materia no puede ser nulo.");
        }
        if (m.getName() == null || m.getName().trim().length() < 3 || m.getName().trim().length() > 100) {
            throw new IllegalArgumentException("El nombre es obligatorio y debe tener entre 3 y 100 caracteres.");
        }
        if (m.getCredits() < CREDITOS_MIN || m.getCredits() > CREDITOS_MAX) {
            throw new IllegalArgumentException("Los creditos deben estar entre " + CREDITOS_MIN + " y " + CREDITOS_MAX + ".");
        }
    }
}

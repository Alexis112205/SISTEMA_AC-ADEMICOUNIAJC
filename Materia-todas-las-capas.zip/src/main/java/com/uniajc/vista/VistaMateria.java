package com.uniajc.vista;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.uniajc.controlador.ControladorMateria;
import com.uniajc.modelo.Materia;

/**
 * Vista de consola (Scanner) para la gestion de materias.
 */
public class VistaMateria {

    private final ControladorMateria controlador;
    private final Scanner scanner;

    public VistaMateria() {
        this.controlador = new ControladorMateria();
        this.scanner = new Scanner(System.in);
    }

    public void iniciar() {
        int opcion = -1;
        do {
            System.out.println("\n=============================================");
            System.out.println("   GESTION DE MATERIAS - MODO CONSOLA        ");
            System.out.println("=============================================");
            System.out.println("1. Listar todas las materias");
            System.out.println("2. Registrar nueva materia");
            System.out.println("3. Buscar materia por ID");
            System.out.println("4. Actualizar materia");
            System.out.println("5. Eliminar materia");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine().trim());

                switch (opcion) {
                    case 1 -> listar();
                    case 2 -> registrar();
                    case 3 -> buscarPorId();
                    case 4 -> actualizar();
                    case 5 -> eliminar();
                    case 0 -> System.out.println("Saliendo de materias...");
                    default -> System.out.println("Opcion no valida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor ingrese un numero valido.");
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (opcion != 0);
    }

    private void listar() {
        System.out.println("\n--- LISTA DE MATERIAS ---");
        List<Materia> lista = controlador.listarTodos();
        if (lista.isEmpty()) {
            System.out.println("No hay materias registradas.");
            return;
        }
        lista.forEach(System.out::println);
    }

    private void registrar() {
        System.out.println("\n--- REGISTRAR MATERIA ---");
        String nombre = leerTexto("Nombre de la materia: ");
        int creditos = leerEntero("Creditos (1 a 10): ");
        controlador.registrar(nombre, creditos);
        System.out.println("Materia registrada correctamente.");
    }

    private void buscarPorId() {
        int id = leerEntero("ID de la materia: ");
        Optional<Materia> materia = controlador.buscarPorId(id);
        if (materia.isPresent()) {
            System.out.println(materia.get());
        } else {
            System.out.println("No se encontro la materia.");
        }
    }

    private void actualizar() {
        int id = leerEntero("ID de la materia a actualizar: ");
        String nombre = leerTexto("Nuevo nombre: ");
        int creditos = leerEntero("Nuevos creditos (1 a 10): ");
        controlador.actualizar(id, nombre, creditos);
        System.out.println("Materia actualizada correctamente.");
    }

    private void eliminar() {
        int id = leerEntero("ID de la materia a eliminar: ");
        controlador.eliminar(id);
        System.out.println("Materia eliminada correctamente.");
    }

    private String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine();
    }

    private int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Escriba un numero valido.");
            }
        }
    }
}

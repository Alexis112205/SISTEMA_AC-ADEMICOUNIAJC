package com.uniajc.vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import com.uniajc.controlador.ControladorMateria;
import com.uniajc.modelo.Materia;

/**
 * Interfaz grafica (Swing) para la gestion de Materias. Misma paleta que VistaEstudianteSwing.
 */
public class VistaMateriaSwing extends JPanel {

    private static final Color COLOR_PRIMARIO = new Color(41, 128, 185);
    private static final Color COLOR_SECUNDARIO = new Color(236, 240, 241);
    private static final Color COLOR_EXITO = new Color(39, 174, 96);
    private static final Color COLOR_PELIGRO = new Color(231, 76, 60);
    private static final Color COLOR_GRIS = new Color(149, 165, 166);

    private static final String[] COLUMNAS = {"ID", "Nombre", "Creditos"};

    private final ControladorMateria controlador;
    private final DefaultTableModel modeloTabla;
    private final JTable tabla;
    private final JTextField textoBusqueda = new JTextField(25);

    public VistaMateriaSwing() {
        this.controlador = new ControladorMateria();

        setLayout(new BorderLayout(15, 15));
        setBackground(COLOR_SECUNDARIO);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        modeloTabla = new DefaultTableModel(COLUMNAS, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setRowHeight(25);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setSelectionBackground(COLOR_PRIMARIO);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabla.getTableHeader().setBackground(COLOR_PRIMARIO);
        tabla.getTableHeader().setForeground(Color.WHITE);

        add(crearPanelNorte(), BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(COLOR_PRIMARIO, 2));
        add(scroll, BorderLayout.CENTER);
        add(crearPanelBotones(), BorderLayout.SOUTH);

        cargarMaterias();
    }

    private JPanel crearPanelNorte() {
        JPanel norte = new JPanel(new BorderLayout(10, 10));
        norte.setBackground(COLOR_SECUNDARIO);

        JLabel titulo = new JLabel("Gestion de Materias - UNIAJC");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 17));
        titulo.setForeground(COLOR_PRIMARIO);
        norte.add(titulo, BorderLayout.NORTH);

        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        busqueda.setBackground(COLOR_SECUNDARIO);
        JLabel etiqueta = new JLabel("Buscar materia:");
        etiqueta.setFont(new Font("Segoe UI", Font.BOLD, 12));
        textoBusqueda.setPreferredSize(new Dimension(200, 28));
        JButton botonBuscar = crearBoton("Buscar", COLOR_PRIMARIO);
        botonBuscar.addActionListener(e -> buscarMaterias());
        busqueda.add(etiqueta);
        busqueda.add(textoBusqueda);
        busqueda.add(botonBuscar);
        norte.add(busqueda, BorderLayout.SOUTH);
        return norte;
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panel.setBackground(COLOR_SECUNDARIO);

        JButton registrar = crearBoton("Registrar", COLOR_EXITO);
        registrar.addActionListener(e -> abrirFormulario(null));
        JButton editar = crearBoton("Editar", COLOR_PRIMARIO);
        editar.addActionListener(e -> editarSeleccionada());
        JButton eliminar = crearBoton("Eliminar", COLOR_PELIGRO);
        eliminar.addActionListener(e -> eliminarSeleccionada());
        JButton actualizar = crearBoton("Actualizar", COLOR_GRIS);
        actualizar.addActionListener(e -> cargarMaterias());

        panel.add(registrar);
        panel.add(editar);
        panel.add(eliminar);
        panel.add(actualizar);
        return panel;
    }

    private JButton crearBoton(String texto, Color color) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setOpaque(true);
        boton.setPreferredSize(new Dimension(110, 35));
        return boton;
    }

    private void cargarMaterias() {
        try {
            mostrarEnTabla(controlador.listarTodos());
        } catch (RuntimeException ex) {
            mostrarError(ex);
        }
    }

    private void buscarMaterias() {
        String busqueda = textoBusqueda.getText().trim().toLowerCase();
        try {
            List<Materia> materias = controlador.listarTodos();
            if (!busqueda.isEmpty()) {
                materias.removeIf(m -> !(String.valueOf(m.getId()).contains(busqueda)
                        || m.getName().toLowerCase().contains(busqueda)));
            }
            mostrarEnTabla(materias);
        } catch (RuntimeException ex) {
            mostrarError(ex);
        }
    }

    private void mostrarEnTabla(List<Materia> materias) {
        modeloTabla.setRowCount(0);
        for (Materia m : materias) {
            modeloTabla.addRow(new Object[]{m.getId(), m.getName(), m.getCredits()});
        }
    }

    private void editarSeleccionada() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione una fila.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) modeloTabla.getValueAt(fila, 0);
        try {
            controlador.buscarPorId(id).ifPresent(this::abrirFormulario);
        } catch (RuntimeException ex) {
            mostrarError(ex);
        }
    }

    private void abrirFormulario(Materia existente) {
        JTextField nombre = new JTextField(existente == null ? "" : existente.getName(), 20);
        JTextField creditos = new JTextField(existente == null ? "" : String.valueOf(existente.getCredits()), 20);

        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        formulario.add(new JLabel("Nombre:"));
        formulario.add(nombre);
        formulario.add(new JLabel("Creditos (1 a 10):"));
        formulario.add(creditos);

        String titulo = existente == null ? "Registrar materia" : "Editar materia";
        int respuesta = JOptionPane.showConfirmDialog(this, formulario, titulo,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (respuesta != JOptionPane.OK_OPTION) {
            return;
        }

        int valorCreditos;
        try {
            valorCreditos = Integer.parseInt(creditos.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Los creditos deben ser un numero entero.",
                    "Validacion", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            if (existente == null) {
                controlador.registrar(nombre.getText().trim(), valorCreditos);
                JOptionPane.showMessageDialog(this, "Materia registrada.", "Exito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                controlador.actualizar(existente.getId(), nombre.getText().trim(), valorCreditos);
                JOptionPane.showMessageDialog(this, "Materia actualizada.", "Exito", JOptionPane.INFORMATION_MESSAGE);
            }
            cargarMaterias();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validacion", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException ex) {
            mostrarError(ex);
        }
    }

    private void eliminarSeleccionada() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione una fila.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirmacion = JOptionPane.showConfirmDialog(this,
                "Eliminar la materia seleccionada?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            controlador.eliminar((int) modeloTabla.getValueAt(fila, 0));
            JOptionPane.showMessageDialog(this, "Materia eliminada.", "Exito", JOptionPane.INFORMATION_MESSAGE);
            cargarMaterias();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validacion", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException ex) {
            mostrarError(ex);
        }
    }

    private void mostrarError(RuntimeException ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

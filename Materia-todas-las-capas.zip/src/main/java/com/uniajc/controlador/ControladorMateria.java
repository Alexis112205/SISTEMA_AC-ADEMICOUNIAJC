package com.uniajc.controlador;

import java.util.List;
import java.util.Optional;

import com.uniajc.dao.GrupoDao;
import com.uniajc.dao.MateriaDao;
import com.uniajc.modelo.Materia;
import com.uniajc.servicios.MateriaService;

/**
 * Capa de Controlador para Materia. Orquesta la interaccion entre las Vistas
 * (Swing/Consola) y el Servicio. No imprime nada.
 */
public class ControladorMateria {

    private final MateriaService materiaService;

    public ControladorMateria() {
        this.materiaService = new MateriaService(new MateriaDao(), new GrupoDao());
    }

    public ControladorMateria(MateriaService materiaService) {
        this.materiaService = materiaService;
    }

    public void registrar(String nombre, int creditos) {
        materiaService.registrarMateria(new Materia(nombre, creditos));
    }

    public List<Materia> listarTodos() {
        return materiaService.obtenerTodasLasMaterias();
    }

    public Optional<Materia> buscarPorId(int id) {
        return materiaService.buscarPorId(id);
    }

    public void actualizar(int id, String nombre, int creditos) {
        materiaService.actualizarMateria(new Materia(id, nombre, creditos));
    }

    public void eliminar(int id) {
        materiaService.eliminarMateria(id);
    }

    public MateriaService getService() {
        return materiaService;
    }
}

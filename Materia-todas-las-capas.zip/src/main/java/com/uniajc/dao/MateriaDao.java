package com.uniajc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.uniajc.config.ConexionPostgresDatabase;
import com.uniajc.modelo.Materia;

/**
 * Data Access Object (DAO) para la entidad {@link Materia}.
 * Operaciones CRUD sobre la tabla "practica-mvc".materias (PostgreSQL / Neon).
 */
public class MateriaDao {

    private static final String TABLA = "\"practica-mvc\".materias";

    public void guardar(Materia materia) {
        String sql = "INSERT INTO " + TABLA + " (name, credits) VALUES (?, ?)";

        try (Connection conn = ConexionPostgresDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, materia.getName());
            pstmt.setInt(2, materia.getCredits());

            if (pstmt.executeUpdate() > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        materia.setId(generatedKeys.getInt(1));
                    }
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al guardar la materia en la base de datos: " + e.getMessage(), e);
        }
    }

    public List<Materia> obtenerTodos() {
        List<Materia> lista = new ArrayList<>();
        String sql = "SELECT id, name, credits FROM " + TABLA + " ORDER BY id ASC";

        try (Connection conn = ConexionPostgresDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearMateria(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al consultar todas las materias: " + e.getMessage(), e);
        }
        return lista;
    }

    public Optional<Materia> buscarPorId(int id) {
        String sql = "SELECT id, name, credits FROM " + TABLA + " WHERE id = ?";

        try (Connection conn = ConexionPostgresDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearMateria(rs));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar materia por ID: " + e.getMessage(), e);
        }
        return Optional.empty();
    }

    public void actualizar(Materia materia) {
        String sql = "UPDATE " + TABLA + " SET name = ?, credits = ? WHERE id = ?";

        try (Connection conn = ConexionPostgresDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, materia.getName());
            pstmt.setInt(2, materia.getCredits());
            pstmt.setInt(3, materia.getId());

            if (pstmt.executeUpdate() == 0) {
                throw new RuntimeException("No se encontro ninguna materia para actualizar con ID: " + materia.getId());
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar materia: " + e.getMessage(), e);
        }
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM " + TABLA + " WHERE id = ?";

        try (Connection conn = ConexionPostgresDatabase.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            if (pstmt.executeUpdate() == 0) {
                throw new RuntimeException("No se encontro ninguna materia para eliminar con ID: " + id);
            }
        } catch (SQLException e) {
            // Una materia con grupos asociados no se puede borrar (llave foranea)
            throw new RuntimeException("Error al eliminar materia: " + e.getMessage(), e);
        }
    }

    private Materia mapearMateria(ResultSet rs) throws SQLException {
        return new Materia(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getInt("credits")
        );
    }
}

package com.uniajc.modelo;

import java.io.Serializable;
import java.util.Objects;

/**
 * Entidad de dominio Materia (POJO). Mapea con la tabla "practica-mvc".materias.
 * Sin logica de negocio y sin System.out.
 */
public class Materia implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String name;
    private int credits;

    public Materia() {
    }

    /** Para registrar una materia nueva (el ID lo genera la base de datos). */
    public Materia(String name, int credits) {
        this.name = name;
        this.credits = credits;
    }

    /** Constructor completo (mapeo desde la base de datos). */
    public Materia(int id, String name, int credits) {
        this.id = id;
        this.name = name;
        this.credits = credits;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }

    // Alias en espanol (compatibilidad con la guia UNIAJC: nombre_materia, creditos)
    public String getNombre() { return name; }
    public void setNombre(String nombre) { this.name = nombre; }

    public int getCreditos() { return credits; }
    public void setCreditos(int creditos) { this.credits = creditos; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Materia that = (Materia) o;
        return id == that.id && credits == that.credits && Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, credits);
    }

    @Override
    public String toString() {
        return "Materia{id=" + id + ", name='" + name + "', credits=" + credits + "}";
    }
}
